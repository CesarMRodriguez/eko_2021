Java.perform( function () {

	var Log = Java.use("android.util.Log");
	var MainActivity = Java.use("com.blog.basiccalculator.MainActivity");

	MainActivity.add.implementation = function (n1, n2) {
		Log.d("FRIDA","Entra por Frida");
		return this.add(n1,n2);
	}
});
